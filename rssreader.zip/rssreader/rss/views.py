from django.shortcuts import render,redirect
# Create your views here.
import feedparser
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from .serializers import FeedSerializer
from .models import Feed
import requests
from bs4 import BeautifulSoup
import re

def index(request):
        return render(request, 'rss/reader.html')

@csrf_exempt
def rest_feeds(request):
        if request.method == "GET":
                feeds = Feed.objects.all()
                serializer = FeedSerializer(feeds, many=True)
                return JsonResponse(serializer.data, safe=False)

        elif request.method == "POST":
                data = JSONParser().parse(request)
                serializer = FeedSerializer(data=data)

                if serializer.is_valid():
                        serializer.save()
                        return JsonResponse(serializer.data, status=201)

                return JsonResponse(serializer.errors, status=400)   

@csrf_exempt
def rest_feeds_detail(request, pk):
        try:
                feed = Feed.objects.get(pk=pk)
        except Feed.DoesNotExist:
                return HttpResponse(status=404)

        if request.method == "GET":
                serializer = FeedSerializer(feed)
                return JsonResponse(serializer.data)

        elif request.method == "PUT":
                data = JSONParser().parse(request)
                serializer = FeedSerializer(feed, data=data)

                if serializer.is_valid():
                        serializer.save()
                        return JsonResponse(serializer.data)

                return JsonResponse(serializer.errors, status=400)

        elif request.method == "DELETE":
                feed.delete()
                return HttpResponse()
@csrf_exempt
def rest_scraping_items(request):
    scrapingitems=[]
    feeds=Feed.objects.all()
    for feed in feeds:
        response=requests.get(feed.url)
        x=response.headers['content-type']
        y=re.sub(r"\s+", "", x)
        if not(y=='application/rss+xml;charset=UTF-8'or y=='application/xml;charset=UTF-8' or y=='application/xml;charset=utf-8' or y=='application/rdf+xml;charset=UTF-8'or y=='application/rdf+xml;charset==utf-8'):
                    response=requests.get(feed.url)
                    #response.headers['Content-Type']
                    soup=BeautifulSoup(response.content,"lxml")
                    content=[]
                    dictonary={}
                    def gettile(soup):
                        title = ''
                        if soup.title.string is not None:
                            title = soup.title.string
                        elif soup.find("h1") is not None:
                            title = soup.find("h1")
                        dictonary["TITLESCRAPING"]=title
                    def getdescription(soup):
                        description = ''
                        if soup.find("meta", property="og:description") is not None:
                            description = soup.find("meta", property="og:description").get('content')
                        elif soup.find("p") is not None:
                            description = soup.find("p").content
                        dictonary["DESCRIPTIONSCRAPING"]=description
                    def getimage(soup):
                        image = ''
                        if soup.find("meta", property="og:image") is not None:
                            image = soup.find("meta", property="og:image").get('content')
                        elif soup.find("img") is not None:
                            image = soup.find("img").get('href')
                        dictonary["IMAGESCRAPING"]=image
                    def getlink(soup):
                        link=''
                        if soup.find("meta",property="og:url") is not None:
                            link=soup.find("meta",property="og:url").get('content')
 
                        else:
                            link=soup
                        dictonary["LINKSCRAPING"]=link
                    gettile(soup)
                    getdescription(soup)
                    getimage(soup)
                    getlink(soup)    
                    scrapingitems.append(dictonary)
               
        else:
                    pass        
               
    return JsonResponse(scrapingitems, safe=False)           
                              
@csrf_exempt
def rest_items(request):
        feeds = Feed.objects.all()
        items = []
        for feed in feeds:
                response=requests.get(feed.url)
                x=response.headers['content-type']
                y=re.sub(r"\s+", "", x)
                if(y=='application/rss+xml;charset=UTF-8'or y=='application/xml;charset=UTF-8' or y=='application/xml;charset=utf-8' or y=='application/rdf+xml;charset=UTF-8'or y=='application/rdf+xml;charset==utf-8'):
                   rss = feedparser.parse(feed.url)
                   #print(type(rss))
                   try:
                       items.extend(rss["items"])
                   except KeyError:
                       continue
       
        items = list(reversed(sorted(items, key=lambda item: item["published_parsed"])))
        return JsonResponse(items, safe=False)                